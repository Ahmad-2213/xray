# alwaysdata-xray
Simple script to initialize xray on alwaysdata

Heavily inspired by [armgham](https://github.com/armgham/xray-codesandbox) & [fscarmen2](https://github.com/fscarmen2/Argo-Xray-JS-PaaS)

Special thanks to iSegaro & [xiaozhi](https://github.com/xiaozhiob)

[آموزش](https://s1q0.github.io/alwaysdata-xray)
