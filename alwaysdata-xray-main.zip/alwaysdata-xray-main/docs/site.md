﻿## تنظیمات سایت و اتصال
از قسمت Web وارد Sites بشین و تنظیمات سایتتون رو ویرایش کنید


<div align=center>
<img width="1000" src="./pics/18.png"/>
</div>


وارد تب advanced بشید و مقدار idle time رو به صفر تغییر بدید. اما هنوز submit رو نزنید و برگردید قسمت configuration
type رو به user program تغییر بدید و دستور زیر رو وارد قسمت command کنید:

<div dir="ltr">

    ./xray -c config.json

</div>

<div align=center>
<img width="500" src="./pics/11.png"/>
</div>


حالا بر روی submit کلیک کنید.


برگردید لیست site ها و روی restart کلیک کنید

<div align=center>
<img width="500" src="./pics/12.png"/>
</div>

اگر با مشاهده دایرکتوری /vmess سایتتون با همچنین پیامی رو به رو شدید، یعنی تا اینجا همه چیز رو درست انجام دادید.

<div align=center>
<img width="500" src="./pics/13.png"/>
</div>

تنظیمات اتصالتون همچین چیزی میشه

<div align=center>
<img width="700" src="./pics/14.png"/>
</div>

alpn (h2, http/1.1) و uTLS های مختلف رو امتحان کنید، از هرچی وصل شد میتونید استفاده کنید.

[بعدی](cloudflare)
