## مقدمه
سلام. امروز میخوایم با xray سرور اشتراکی شخصی خودمونو راه بندازیم.
اگر اکانت ندارید، قبل از همه چیز اکانت [alwaysdata](https://www.alwaysdata.com/en/register/) و [cloudflare](https://dash.cloudflare.com/sign-up) خودتون رو ایجاد کنید.
[بعدی](account)
