﻿## تنظیمات سایت
در پنل alwaysdata وارد قسمت Remote access > ssh بشید.

<div align=center>
<img width="1200" src="./pics/5.png"/>
</div>

اسم یوزر پیشفرض با اسم سایت یکیه. با کلیک بر روی چرخ دنده جلو اسم وارد تنظیمات حساب بشید و تیک enable password login رو بزنید و در آخر بر روی submit کلیک کنید.

<div align=center>
<img width="1000" src="./pics/6.png"/>
</div>

[بعدی](ssh)
